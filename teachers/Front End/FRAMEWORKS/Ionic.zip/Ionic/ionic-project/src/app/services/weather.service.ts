import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class WeatherService {
  constructor(private http: HttpClient) {}

  baseUrl = 'https://api.weatherbit.io/v2.0';
  apiKey = '0e9d80067b8e46d1b6c5649b178cd73c';
  myCity = 'Luxembourg';

  getWeather() {
    return this.http.get(
      this.baseUrl + '/current?key=' + this.apiKey + '&city=' + this.myCity
    );
  }

  getPrevisions() {
    return this.http.get(
      this.baseUrl +
        '/forecast/daily?key=' +
        this.apiKey +
        '&city=' +
        this.myCity +
        '&days=7'
    );
  }

  getAlerts() {
    return this.http.get(
      this.baseUrl + '/alerts?key=' + this.apiKey + '&city=' + this.myCity
    );
  }
}
