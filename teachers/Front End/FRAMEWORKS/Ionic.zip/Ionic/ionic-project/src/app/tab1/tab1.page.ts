import { Component } from '@angular/core';
import { WeatherService } from '../services/weather.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
})
export class Tab1Page {
  constructor(private ws: WeatherService) {}

  weatherResult: any = null;
  city = '';

  ngOnInit() {
    this.ws.getWeather().subscribe((res: any) => {
      this.weatherResult = res.data[0];
    });
  }
}
