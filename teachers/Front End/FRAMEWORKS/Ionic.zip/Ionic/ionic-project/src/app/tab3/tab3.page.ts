import { Component } from '@angular/core';
import { WeatherService } from '../services/weather.service';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
})
export class Tab3Page {
  constructor(private ws: WeatherService) {}

  alerts: any = null;
  city = '';

  ngOnInit() {
    this.showAlerts();
  }

  showAlerts() {
    this.ws.getAlerts().subscribe((res: any) => {
      this.alerts = res.alerts;
      this.city = res.city_name;
    });
  }
}
