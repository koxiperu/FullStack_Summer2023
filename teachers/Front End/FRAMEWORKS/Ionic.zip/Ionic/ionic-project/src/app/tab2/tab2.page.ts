import { Component } from '@angular/core';
import { WeatherService } from '../services/weather.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
})
export class Tab2Page {
  constructor(private ws: WeatherService) {}

  weatherResult: any = null;
  city = '';

  ngOnInit() {
    this.previsions();
  }

  previsions() {
    this.ws.getPrevisions().subscribe((res: any) => {
      this.city = res.city_name;
      this.weatherResult = res.data;
    });
  }
}
