<?php
class Candy {
    public $id;
    public $name;
    public $price;
    public $categ;
}
?>