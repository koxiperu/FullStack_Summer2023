//variables for checking is name and date are correct
var nameOk = false;
var dateOk = false;
//listen the input name field
document.querySelector("#victim").addEventListener("keyup", function () {
  const victimName = document.querySelector("#victim");
  const name = victimName.value;
  const arr=name.split(" ");
  if (name.indexOf(" ")>-1) {
    if((arr[0].length>0)&&(arr[1].length>0)){
    victimName.style.borderColor = "green";
    nameOk = true;
    
    //if everithing is ok, enabled the submit-button   
  } else {
    victimName.style.borderColor = "red";
    nameOk = false;    
  }
  } else {
    victimName.style.borderColor = "red";
    nameOk = false;
  }
  
});
//listen the input date field
document.querySelector("#carry").addEventListener("keyup", function () {
  const victimDate = document.querySelector("#carry");
  const date = victimDate.value;
  if (date.length > 3) {
    victimDate.style.borderColor = "green";
    dateOk = true;    
    //if everithing is ok, enabled the submit-button   
  } else {
    victimDate.style.borderColor = "red";
    dateOk = false;    
  }

});
