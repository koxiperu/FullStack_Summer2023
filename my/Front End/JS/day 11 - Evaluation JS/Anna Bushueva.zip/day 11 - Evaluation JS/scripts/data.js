const patientArray = [
    {
      pictureUrl: 'images/patients/heart.png',
      quantity: 0,
    },
    {
      pictureUrl: 'images/patients/liver.png',
      quantity: 0,
    },
    {
      pictureUrl: 'images/patients/eyes.jpg',
      quantity: 4,
    },
    {
      pictureUrl: 'images/patients/kidney.jpg',
      quantity: 0,
    },
    {
      pictureUrl: 'images/patients/hairs.jpg',
      quantity: 5,
    },
    {
      pictureUrl: 'images/patients/teeth.png',
      quantity: 12,
    },
    {
      pictureUrl: 'images/patients/stomash.jpg',
      quantity: 0,
    },
    {
      pictureUrl: 'images/patients/testies.png',
      quantity: 1,
    },
    {
      pictureUrl: 'images/patients/lungs.jpg',
      quantity: 2,
    },
    {
      pictureUrl: 'images/patients/brain.png',
      quantity: 0,
    },
  ];